package CHI::Test::Driver::NonMoose;
use Carp;
use strict;
use warnings;
use base qw(CHI::Driver::Memory);

1;
