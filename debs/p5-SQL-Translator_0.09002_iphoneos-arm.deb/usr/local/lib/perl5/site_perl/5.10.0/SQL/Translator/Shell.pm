package SQL::Translator::Shell;

# ----------------------------------------------------------------------
# $Id: Shell.pm,v 1.1 2003-10-03 21:13:37 dlc Exp $ 
# ----------------------------------------------------------------------
# SQL::Translator::Shell - interactive interface to a parsed schema
# Copyright (C) 2003 darren chamberlain <darren@cpan.org>
# ----------------------------------------------------------------------

use strict;
use vars qw($VERSION $REVISION $DEBUG);


1;

__END__

# This is a placeholder!
