package SQL::Translator::Schema::Graph::Port;

use strict;

1;
