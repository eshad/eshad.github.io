package Geo::Coordinates::Converter::Datum::Jgd2000;

use strict;
use warnings;
use base qw( Geo::Coordinates::Converter::Datum::Grs80 );

sub name { 'jgd2000' }

1;
