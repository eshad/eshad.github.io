SWF::File samples.

sample.plx  - create a sample movie. Two rotating rectangles.
jpg2swf.plx - convert JPEG to SWF using DefineBitsJPEG2.
img2swf.plx - convert a bitmap to SWF using DefineBitsLossless/2.
              (Image::Magick is needed)
linkext.plx - extract URL referred by 'getURL' action.