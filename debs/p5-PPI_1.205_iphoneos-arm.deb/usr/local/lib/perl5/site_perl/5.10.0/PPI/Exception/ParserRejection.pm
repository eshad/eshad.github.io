package PPI::Exception::ParserRejection;

use strict;
use PPI::Exception ();

use vars qw{$VERSION @ISA};
BEGIN {
	$VERSION = '1.205';
	@ISA     = 'PPI::Exception';
}

1;
