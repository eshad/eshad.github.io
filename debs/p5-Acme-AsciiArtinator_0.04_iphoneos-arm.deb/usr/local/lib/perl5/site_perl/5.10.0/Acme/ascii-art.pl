
$_="rst";;;;;;;;;
 while(<>){print
  "Hello",", ",
   "world!\n" 
    if /st/;}
     #######
      #####
       ###
        #