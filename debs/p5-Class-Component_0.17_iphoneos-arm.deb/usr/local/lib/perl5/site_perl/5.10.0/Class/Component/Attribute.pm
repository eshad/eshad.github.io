package Class::Component::Attribute;

use strict;
use warnings;

1;
