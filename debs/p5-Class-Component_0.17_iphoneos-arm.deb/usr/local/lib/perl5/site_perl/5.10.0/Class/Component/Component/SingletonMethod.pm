package Class::Component::Component::SingletonMethod;

use strict;
use warnings;
use base 'Class::Component::Component::Autocall::SingletonMethod';
1;
