package Class::Component::Component::Autocall;

use strict;
use warnings;
use base 'Class::Component::Component::Autocall::Autoload';
1;
