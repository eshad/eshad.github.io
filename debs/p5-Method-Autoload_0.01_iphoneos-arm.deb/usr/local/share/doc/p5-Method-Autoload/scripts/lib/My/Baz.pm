package My::Baz;
use strict;
use warnings;
sub foo {"My::Baz::foo"};
sub bar {"My::Baz::bar"};
sub baz {"My::Baz::baz"};
1;
