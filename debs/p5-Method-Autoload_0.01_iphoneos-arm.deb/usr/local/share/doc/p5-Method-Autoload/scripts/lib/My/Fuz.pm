package My::Fuz;
use strict;
use warnings;
sub fuz {"My::Fuz::fuz"};
1;
