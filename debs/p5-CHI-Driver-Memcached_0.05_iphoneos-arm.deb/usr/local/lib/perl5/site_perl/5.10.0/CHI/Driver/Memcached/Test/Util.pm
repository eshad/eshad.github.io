package CHI::Driver::Memcached::Test::Util;
use Test::Builder;
use Test::More;
use strict;
use warnings;
use base qw(Exporter);

our @EXPORT_OK = qw();

1;
