AMF::Perl: Flash Remoting in Perl. 
See http://www.simonf.com/flap for more information

Version: 0.15
Date: September 17, 2004.

This is the code and several examples that show the possibility of using Perl to talk to a Macromedia Flash client using AMF (Action Message Format).

To install:

1a. If you have access to Macromedia Flash MX, load the docs/examples/cpu/CpuExample.fla file.  Edit the actions for Layer Name to use the URL of your script.

1b. If you do not have Macromedia authoringh tools, embed the
docs/examples/cpu/CpuExample.swf movie into a web page. 
Use docs/examples/cpu/cpu.html as a template. When the movie starts, enter the URL of your script into the text field.

2. Observe the load of your server when you click Refresh!

Simon Ilyushchenko
