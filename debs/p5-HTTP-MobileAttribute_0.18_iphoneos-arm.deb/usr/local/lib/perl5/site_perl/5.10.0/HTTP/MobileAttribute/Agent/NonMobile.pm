package HTTP::MobileAttribute::Agent::NonMobile;
use strict;
use warnings;
use HTTP::MobileAttribute::Agent::Base;

sub parse     { } # nop
sub model     { '' }
sub device_id { '' }

1;
