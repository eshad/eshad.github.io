GML 3.1.1 profile gmlsfProfile 1.0.0 examples

2008-05-20  Kevin Stegemoller

  * gmlsfProfile/1.0.0/examples/exampleHydrographySchema.xsd: one
    non-content-changing bug fix for GML 3.1.1 location
  * gmlsfProfile/1.0.0/examples/exampleRoads_BtsSchema.xsd: three
    non-content-changing bug fixes including fix GML 3.1.1 location; fix close
    complexType start tag found by David Valentine (valentin at sdsc.edu); fix
    case on extension type definition
  * gmlsfProfile/1.0.0/examples/exampleReporterSchema.xsd: four
    non-content-changing bug fixes including fix close appinfo start tag; fix
    GML 3.1.1 location; fix close complexType start tag; fix case on extension
    type definition

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

Copyright (c) 2007-2008 Open Geospatial Consortium, Inc. All Rights Reserved.

-----------------------------------------------------------------------
