This set of XML Schema Documents for GML Version 3.1.1 has been edited
to reflect the corrigendum to documents 0GC 03-105r1 and OGC 04-092r4 
that is based on the change requests: 
OGC 05-068r1 "Store xlinks.xsd file at a fixed location"
OGC 05-081r2 "Change to use relative paths"
OGC 05-105 "Remove description and copyright tags from XML schema documents"

Arliss Whiteside, 2005-11-22

