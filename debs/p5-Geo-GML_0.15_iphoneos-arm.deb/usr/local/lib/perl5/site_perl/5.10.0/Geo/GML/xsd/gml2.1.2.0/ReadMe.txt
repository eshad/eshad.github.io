OpenGIS GML 2.1.2.0 ReadMe.txt

NOTICE:  These are the GML 2.1.2 schema before the Corrigendum 1 for GML 2.1.2
schema fix (OGC 06-189).  These existing 2.1.2 do not validate in conformant
processors.

2007-08-27  Chris Holmes

  * v2.1.2: update 2.1.2.1 and ReadMe.txt changes
  * v2.1.2.0: Contains previous version of GML 2.1.2 (pre- 4 Sep 2007)
  * v2.1.2.1: Contains Corrigendum 1 for GML 2.1.2 schema fix (OGC 06-189).

2005-11-22  Arliss Whiteside

  * GML versions 2.0.0 through 3.1.1: The sets of XML Schema Documents for
    OpenGIS GML Versions 2.0.0 through 3.1.1 have been edited to reflect the
    corrigenda to all those OGC documents that is based on the change requests: 
  OGC 05-068r1 "Store xlinks.xsd file at a fixed location"
  OGC 05-081r2 "Change to use relative paths"
 
  * Note: check each OGC numbered document for detailed changes.

